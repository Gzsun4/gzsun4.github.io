
import React, { useState } from 'react';
import FilamentCalculator from './components/FilamentCalculator';
import ResinCalculator from './components/ResinCalculator';
import { CalculatorType } from './types';
import { CubeIcon, BeakerIcon } from './components/common/Icons';

const App: React.FC = () => {
  const [calculatorType, setCalculatorType] = useState<CalculatorType>('filament');

  const getButtonClasses = (type: CalculatorType) => {
    const baseClasses = 'flex-1 py-3 px-4 text-center text-sm sm:text-base font-semibold rounded-lg transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-100 flex items-center justify-center gap-2';
    if (calculatorType === type) {
      return `${baseClasses} bg-white text-blue-600 shadow-md scale-105`;
    }
    return `${baseClasses} bg-transparent text-gray-500 hover:bg-white/60 hover:text-blue-500`;
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-6 text-center">
          <h1 className="text-3xl sm:text-4xl font-bold text-gray-800">
            Calculadora de Costos de Impresión 3D
          </h1>
          <p className="mt-2 text-md text-gray-600">
            Estima el precio de venta para tus impresiones en filamento y resina.
          </p>
        </div>
      </header>

      <main className="container mx-auto p-4 sm:p-8">
        <div className="max-w-md mx-auto mb-8 p-1.5 bg-gray-200 rounded-xl flex items-center">
          <button
            onClick={() => setCalculatorType('filament')}
            className={getButtonClasses('filament')}
          >
            <CubeIcon className="w-5 h-5" />
            Filamento (FDM)
          </button>
          <button
            onClick={() => setCalculatorType('resin')}
            className={getButtonClasses('resin')}
          >
            <BeakerIcon className="w-5 h-5" />
            Resina (SLA)
          </button>
        </div>
        
        <div key={calculatorType} className="animate-fade-in">
          {calculatorType === 'filament' ? <FilamentCalculator /> : <ResinCalculator />}
        </div>
      </main>

      <footer className="text-center py-6 text-sm text-gray-500">
          <p>Creado con React, TypeScript y Tailwind CSS.</p>
      </footer>
    </div>
  );
};

export default App;
