
export type CalculatorType = 'filament' | 'resin';

export interface Result {
  total: number;
  breakdown: {
    material: number;
    electricidad: number;
    labor: number;
    depreciacion: number;
    fallos: number;
    beneficio: number;
    consumibles?: number;
  };
}
