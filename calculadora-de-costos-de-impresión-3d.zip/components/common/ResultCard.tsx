
import React from 'react';
import { Result } from '../../types';

interface ResultCardProps {
  result: Result | null;
}

const ResultCard: React.FC<ResultCardProps> = ({ result }) => {
  if (!result || result.total <= 0) {
    return (
      <div className="p-6 bg-gray-100 rounded-xl text-center border border-gray-200">
        <p className="text-gray-500">Completa los campos y haz clic en "Calcular" para ver el resultado.</p>
      </div>
    );
  }

  const formatCurrency = (value: number) => {
    return value.toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
  };

  const subtotal = result.breakdown.material + result.breakdown.electricidad + result.breakdown.labor + result.breakdown.depreciacion + (result.breakdown.consumibles || 0) + result.breakdown.fallos;

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
      <h3 className="text-lg font-semibold text-gray-800 mb-4 text-center">Precio de Venta Sugerido</h3>
      <div className="text-center mb-6">
        <p className="text-5xl font-bold text-blue-600">{formatCurrency(result.total)}</p>
        <p className="text-sm text-gray-500">Impuestos no incluidos</p>
      </div>

      <h4 className="text-md font-semibold text-gray-700 mb-3">Desglose de Costos</h4>
      <div className="space-y-2 text-sm">
        <div className="flex justify-between items-center py-2 border-b">
          <span className="text-gray-600">Costo de Material</span>
          <span className="font-medium text-gray-800">{formatCurrency(result.breakdown.material)}</span>
        </div>
        <div className="flex justify-between items-center py-2 border-b">
          <span className="text-gray-600">Costo de Electricidad</span>
          <span className="font-medium text-gray-800">{formatCurrency(result.breakdown.electricidad)}</span>
        </div>
        <div className="flex justify-between items-center py-2 border-b">
          <span className="text-gray-600">Mano de Obra / Post-procesado</span>
          <span className="font-medium text-gray-800">{formatCurrency(result.breakdown.labor)}</span>
        </div>
        {result.breakdown.consumibles !== undefined && result.breakdown.consumibles > 0 && (
          <div className="flex justify-between items-center py-2 border-b">
            <span className="text-gray-600">Consumibles (IPA, etc.)</span>
            <span className="font-medium text-gray-800">{formatCurrency(result.breakdown.consumibles)}</span>
          </div>
        )}
        <div className="flex justify-between items-center py-2 border-b">
          <span className="text-gray-600">Amortización / Desgaste</span>
          <span className="font-medium text-gray-800">{formatCurrency(result.breakdown.depreciacion)}</span>
        </div>
        <div className="flex justify-between items-center py-2 border-b">
          <span className="text-gray-600">Margen por Fallos ({result.breakdown.fallos / subtotal * 100}%)</span>
          <span className="font-medium text-gray-800">{formatCurrency(result.breakdown.fallos)}</span>
        </div>
        <div className="flex justify-between items-center pt-3 mt-2 border-t-2">
          <span className="text-gray-600 font-semibold">Costo Total</span>
          <span className="font-bold text-gray-900">{formatCurrency(subtotal)}</span>
        </div>
        <div className="flex justify-between items-center py-2 bg-green-50 rounded-md px-2 mt-1">
          <span className="text-green-800 font-semibold">Margen de Beneficio</span>
          <span className="font-bold text-green-800">{formatCurrency(result.breakdown.beneficio)}</span>
        </div>
      </div>
    </div>
  );
};

export default ResultCard;
