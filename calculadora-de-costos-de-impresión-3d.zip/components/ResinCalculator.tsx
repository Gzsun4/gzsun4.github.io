
import React, { useState, useCallback } from 'react';
import InputField from './common/InputField';
import ResultCard from './common/ResultCard';
import { Result } from '../types';

const INITIAL_STATE = {
    volumenResina: '120',
    costoBotellaResina: '40',
    volumenBotellaResina: '1000',
    tiempoImpresionHoras: '6',
    consumoImpresoraWatts: '60',
    costoKWH: '0.15',
    costoConsumibles: '1.50',
    costoHoraHombre: '20',
    tiempoPostProcesadoMinutos: '20',
    depreciacionImpresora: '0.50',
    tasaFallo: '8',
    margenBeneficio: '40',
};

const ResinCalculator: React.FC = () => {
    const [inputs, setInputs] = useState(INITIAL_STATE);
    const [result, setResult] = useState<Result | null>(null);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const { id, value } = e.target;
      setInputs(prev => ({ ...prev, [id]: value }));
    };

    const calculateCost = useCallback(() => {
        const values = Object.fromEntries(
            Object.entries(inputs).map(([key, value]) => [key, parseFloat(value) || 0])
        );

        const {
          volumenResina, costoBotellaResina, volumenBotellaResina, tiempoImpresionHoras,
          consumoImpresoraWatts, costoKWH, costoConsumibles, costoHoraHombre, tiempoPostProcesadoMinutos,
          depreciacionImpresora, tasaFallo, margenBeneficio
        } = values;
    
        const costoMaterial = (volumenResina / (volumenBotellaResina || 1000)) * costoBotellaResina;
        const costoElectricidad = (consumoImpresoraWatts / 1000) * tiempoImpresionHoras * costoKWH;
        const costoLabor = (tiempoPostProcesadoMinutos / 60) * costoHoraHombre;
        const costoDepreciacion = tiempoImpresionHoras * depreciacionImpresora;
    
        const subtotal = costoMaterial + costoElectricidad + costoLabor + costoDepreciacion + costoConsumibles;
        const costoConFallo = subtotal * (tasaFallo / 100);
        const costoTotal = subtotal + costoConFallo;
        
        const beneficio = costoTotal * (margenBeneficio / 100);
        const precioVenta = costoTotal + beneficio;

        if (precioVenta > 0) {
            setResult({
              total: precioVenta,
              breakdown: {
                material: costoMaterial,
                electricidad: costoElectricidad,
                labor: costoLabor,
                consumibles: costoConsumibles,
                depreciacion: costoDepreciacion,
                fallos: costoConFallo,
                beneficio: beneficio,
              },
            });
        } else {
            setResult(null);
        }
    }, [inputs]);

    const clearForm = () => {
      setInputs({
          volumenResina: '', costoBotellaResina: '', volumenBotellaResina: '1000', tiempoImpresionHoras: '',
          consumoImpresoraWatts: '', costoKWH: '', costoConsumibles: '', costoHoraHombre: '', tiempoPostProcesadoMinutos: '',
          depreciacionImpresora: '', tasaFallo: '8', margenBeneficio: '40'
      });
      setResult(null);
    };

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
        <div className="p-6 bg-white rounded-xl shadow-lg border border-gray-200">
          <h3 className="text-xl font-bold text-gray-800 mb-6">Parámetros de Cálculo (Resina)</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InputField label="Volumen de Resina" id="volumenResina" value={inputs.volumenResina} onChange={handleInputChange} unit="ml" placeholder="Ej: 120" />
            <InputField label="Tiempo de Impresión" id="tiempoImpresionHoras" value={inputs.tiempoImpresionHoras} onChange={handleInputChange} unit="horas" placeholder="Ej: 6.5" />
            <InputField label="Costo Botella Resina" id="costoBotellaResina" value={inputs.costoBotellaResina} onChange={handleInputChange} unit="€" placeholder="Ej: 40" />
            <InputField label="Volumen Botella Resina" id="volumenBotellaResina" value={inputs.volumenBotellaResina} onChange={handleInputChange} unit="ml" placeholder="Ej: 1000" />
            <InputField label="Consumo Impresora" id="consumoImpresoraWatts" value={inputs.consumoImpresoraWatts} onChange={handleInputChange} unit="watts" placeholder="Ej: 60" />
            <InputField label="Costo Electricidad" id="costoKWH" value={inputs.costoKWH} onChange={handleInputChange} unit="€/kWh" placeholder="Ej: 0.15" />
            <InputField label="Tiempo Post-Procesado" id="tiempoPostProcesadoMinutos" value={inputs.tiempoPostProcesadoMinutos} onChange={handleInputChange} unit="min" placeholder="Ej: 20" />
            <InputField label="Mano de Obra" id="costoHoraHombre" value={inputs.costoHoraHombre} onChange={handleInputChange} unit="€/hora" placeholder="Ej: 20" />
            <InputField label="Amortización (FEP, LCD)" id="depreciacionImpresora" value={inputs.depreciacionImpresora} onChange={handleInputChange} unit="€/hora" placeholder="Ej: 0.50" />
            <InputField label="Tasa de Fallo" id="tasaFallo" value={inputs.tasaFallo} onChange={handleInputChange} unit="%" placeholder="Ej: 8" />
            <InputField label="Costos Consumibles" id="costoConsumibles" value={inputs.costoConsumibles} onChange={handleInputChange} unit="€" placeholder="Ej: 1.50" helpText="IPA, guantes, etc." />
            <InputField label="Margen de Beneficio" id="margenBeneficio" value={inputs.margenBeneficio} onChange={handleInputChange} unit="%" placeholder="Ej: 40" />
          </div>
        </div>

        <div className="space-y-6 sticky top-8">
          <ResultCard result={result} />
          <div className="flex flex-col sm:flex-row gap-4">
            <button onClick={calculateCost} className="w-full bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
              Calcular Costo
            </button>
            <button onClick={clearForm} className="w-full bg-gray-200 text-gray-700 font-bold py-3 px-6 rounded-lg hover:bg-gray-300 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400">
              Limpiar
            </button>
          </div>
        </div>
      </div>
    );
};

export default ResinCalculator;
